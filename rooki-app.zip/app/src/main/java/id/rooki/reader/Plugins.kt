package id.rooki.reader

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.util.Base64
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import coil.ImageLoader
import dalvik.system.DexClassLoader
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.HttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import org.json.JSONArray
import tsuki.MangaLoaderContext
import tsuki.MangaParser
import tsuki.bitmap.Bitmap
import tsuki.bitmap.Rect
import tsuki.config.MangaSourceConfig
import tsuki.config.ConfigKey
import tsuki.model.MangaSource
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

/** Jalankan blok dan bungkus error (CancellationException tetap dilempar ulang). */
suspend inline fun <T> attempt(block: () -> T): Result<T> = try {
    Result.success(block())
} catch (e: CancellationException) {
    throw e
} catch (e: Throwable) {
    Result.failure(e)
}

fun Throwable.readable(): String {
    var t: Throwable = this
    while (t.cause != null && (t is java.lang.reflect.InvocationTargetException || t is ExceptionInInitializerError)) t = t.cause!!
    return t.message?.takeIf { it.isNotBlank() } ?: t.javaClass.simpleName
}

class RookiApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Plugins.init(this)
        Store.init(this)
    }
}

class SourceInfo(
    val name: String,
    val title: String,
    val locale: String,
    val broken: Boolean,
    val raw: MangaSource,
    val plugin: String,
)

class PluginFile(val file: File, val sources: Int, val error: String?)

object Plugins {
    lateinit var app: Context
    lateinit var ctx: RookiContext

    var sources by mutableStateOf<List<SourceInfo>>(emptyList())
    var files by mutableStateOf<List<PluginFile>>(emptyList())

    private val factories = HashMap<String, () -> MangaParser>()
    private val parsers = HashMap<String, MangaParser>()
    private val loaders = HashMap<String, ImageLoader>()
    private var plain: ImageLoader? = null

    val dir: File get() = File(app.filesDir, "plugins").apply { mkdirs() }

    fun init(a: Application) {
        app = a
        ctx = RookiContext(a)
        reload()
    }

    fun reload() {
        parsers.clear(); loaders.clear(); factories.clear()
        val srcs = ArrayList<SourceInfo>()
        val fl = ArrayList<PluginFile>()
        val seen = HashSet<String>()
        val list = dir.listFiles { f -> f.isFile && f.extension.equals("lip", true) }.orEmpty().sortedBy { it.name }
        for (f in list) {
            try {
                f.setReadOnly() // Android 14+: dex harus read-only
                val cache = File(app.codeCacheDir, "lip_" + f.nameWithoutExtension).apply { mkdirs() }
                val cl = DexClassLoader(f.absolutePath, cache.absolutePath, null, Plugins::class.java.classLoader)
                val enumCls = cl.loadClass("tsuki.model.MangaParserSource")
                val factory = cl.loadClass("tsuki.MangaParserFactoryKt")
                    .getMethod("newParser", enumCls, MangaLoaderContext::class.java)
                val values = enumCls.getMethod("values").invoke(null) as Array<*>
                val gTitle = enumCls.getMethod("getTitle")
                val gLocale = enumCls.getMethod("getLocale")
                val gBroken = enumCls.getMethod("isBroken")
                var n = 0
                for (v in values) {
                    val s = v as MangaSource
                    if (!seen.add(s.name)) continue
                    srcs += SourceInfo(
                        s.name, gTitle.invoke(v) as String, (gLocale.invoke(v) as? String).orEmpty(),
                        gBroken.invoke(v) as Boolean, s, f.name,
                    )
                    factories[s.name] = { factory.invoke(null, v, ctx) as MangaParser }
                    n++
                }
                fl += PluginFile(f, n, null)
            } catch (e: Throwable) {
                fl += PluginFile(f, 0, e.readable())
            }
        }
        sources = srcs.sortedWith(compareBy({ it.locale }, { it.title.lowercase() }))
        files = fl
    }

    fun install(resolver: android.content.ContentResolver, uri: Uri): Result<Unit> = runCatching {
        var name = "plugin.lip"
        resolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: name
        }
        val base = name.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9_-]"), "_").ifBlank { "plugin" }
        val out = File(dir, "$base.lip")
        if (out.exists()) { out.setWritable(true); out.delete() }
        resolver.openInputStream(uri)!!.use { i -> out.outputStream().use { i.copyTo(it) } }
        out.setReadOnly()
        reload()
    }

    fun remove(f: PluginFile) {
        f.file.setWritable(true); f.file.delete()
        File(app.codeCacheDir, "lip_" + f.file.nameWithoutExtension).deleteRecursively()
        reload()
    }

    fun source(name: String) = sources.firstOrNull { it.name == name }

    /** Parser dibuat dari plugin; hasil di-cache. */
    fun parser(name: String): MangaParser? {
        parsers[name]?.let { return it }
        val f = factories[name] ?: return null
        return try { f().also { parsers[name] = it } } catch (e: Throwable) { null }
    }

    fun client(p: MangaParser): OkHttpClient = ctx.httpClient.newBuilder().addInterceptor(p).build()

    /** Pemuat gambar yang memakai interceptor milik parser (Referer, descramble, dll). */
    fun loader(sourceName: String): ImageLoader {
        loaders[sourceName]?.let { return it }
        val p = parser(sourceName) ?: return plainLoader()
        return ImageLoader.Builder(app).callFactory(client(p)).crossfade(true).build().also { loaders[sourceName] = it }
    }

    fun plainLoader(): ImageLoader =
        plain ?: ImageLoader.Builder(app).crossfade(true).build().also { plain = it }
}

// ---------------------------------------------------------------------------------------------

class MemoryCookieJar : CookieJar {
    private val store = HashMap<String, MutableList<Cookie>>()

    @Synchronized
    override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
        val l = store.getOrPut(url.host) { ArrayList() }
        for (c in cookies) { l.removeAll { it.name == c.name && it.path == c.path }; l += c }
    }

    @Synchronized
    override fun loadForRequest(url: HttpUrl): List<Cookie> {
        val now = System.currentTimeMillis()
        val out = ArrayList<Cookie>()
        for ((host, l) in store) {
            if (url.host == host || url.host.endsWith(".$host") || host.endsWith(url.host)) {
                l.removeAll { it.expiresAt < now }
                out += l.filter { it.matches(url) }
            }
        }
        return out
    }
}

class AndroidBitmap(val b: android.graphics.Bitmap) : Bitmap {
    override val width: Int get() = b.width
    override val height: Int get() = b.height
    override fun drawBitmap(sourceBitmap: Bitmap, src: Rect, dst: Rect) {
        val c = android.graphics.Canvas(b)
        c.drawBitmap(
            (sourceBitmap as AndroidBitmap).b,
            android.graphics.Rect(src.left, src.top, src.right, src.bottom),
            android.graphics.Rect(dst.left, dst.top, dst.right, dst.bottom),
            null,
        )
    }
}

/** Implementasi MangaLoaderContext yang disediakan aplikasi untuk plugin. */
private const val UA =
    "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36"

class RookiContext(private val app: Context) : MangaLoaderContext() {

    override val cookieJar: CookieJar = MemoryCookieJar()

    override val httpClient: OkHttpClient = OkHttpClient.Builder()
        .cookieJar(cookieJar)
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(40, TimeUnit.SECONDS)
        .addInterceptor { chain ->
            val r = chain.request()
            chain.proceed(
                if (r.header("User-Agent") == null)
                    r.newBuilder().header("User-Agent", UA).build() else r,
            )
        }
        .build()

    override fun getConfig(source: MangaSource): MangaSourceConfig = object : MangaSourceConfig {
        @Suppress("UNCHECKED_CAST")
        override fun <T> get(key: ConfigKey<T>): T = key.defaultValue
    }

    override fun newParserInstance(source: MangaSource): MangaParser =
        Plugins.parser(source.name) ?: throw IllegalStateException("Sumber tidak ditemukan: ${source.name}")

    override fun getDefaultUserAgent(): String = UA

    override fun encodeBase64(data: ByteArray): String = Base64.encodeToString(data, Base64.NO_WRAP)
    override fun decodeBase64(data: String): ByteArray = Base64.decode(data, Base64.DEFAULT)
    override fun getPreferredLocales(): List<Locale> = listOf(Locale.getDefault())

    override fun requestBrowserAction(parser: MangaParser, url: String): Nothing =
        throw UnsupportedOperationException("Situs meminta verifikasi browser: $url")

    override fun createBitmap(width: Int, height: Int): Bitmap =
        AndroidBitmap(android.graphics.Bitmap.createBitmap(width, height, android.graphics.Bitmap.Config.ARGB_8888))

    override fun redrawImageResponse(response: Response, redraw: (image: Bitmap) -> Bitmap): Response {
        val bytes = response.body!!.bytes()
        val src = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            ?: return response.newBuilder().body(bytes.toResponseBody(response.body?.contentType())).build()
        val out = redraw(AndroidBitmap(src)) as AndroidBitmap
        val bos = ByteArrayOutputStream()
        out.b.compress(android.graphics.Bitmap.CompressFormat.JPEG, 92, bos)
        return response.newBuilder()
            .body(bos.toByteArray().toResponseBody("image/jpeg".toMediaType()))
            .header("Content-Type", "image/jpeg")
            .build()
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override suspend fun evaluateJs(script: String): String? = evaluateJs("about:blank", script)

    @SuppressLint("SetJavaScriptEnabled")
    override suspend fun evaluateJs(baseUrl: String, script: String): String? = withContext(Dispatchers.Main) {
        suspendCancellableCoroutine { cont ->
            val web = WebView(app)
            web.settings.javaScriptEnabled = true
            val done = java.util.concurrent.atomic.AtomicBoolean(false)
            fun finish(v: String?) {
                if (done.compareAndSet(false, true)) { web.destroy(); if (cont.isActive) cont.resume(v) }
            }
            web.webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String?) {
                    view.evaluateJavascript(script) { raw ->
                        finish(
                            if (raw == null || raw == "null") null
                            else runCatching { JSONArray("[$raw]").getString(0) }.getOrDefault(raw),
                        )
                    }
                }
            }
            Handler(Looper.getMainLooper()).postDelayed({ finish(null) }, 15000)
            cont.invokeOnCancellation { Handler(Looper.getMainLooper()).post { finish(null) } }
            web.loadDataWithBaseURL(baseUrl, "<html><body></body></html>", "text/html", "utf-8", null)
        }
    }
}
