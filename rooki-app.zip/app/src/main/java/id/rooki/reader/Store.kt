package id.rooki.reader

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import okhttp3.Request
import tsuki.model.MangaChapter
import java.io.File
import java.security.MessageDigest

@Serializable
data class Item(
    val source: String,
    val url: String,
    val title: String,
    val cover: String? = null,
    val publicUrl: String = "",
    val ts: Long = 0,
    val chapterId: Long = 0,
    val chapterTitle: String = "",
)

@Serializable
data class DlChapter(val id: Long, val title: String, val count: Int)

@Serializable
data class DlMeta(val item: Item, val chapters: List<DlChapter> = emptyList())

object Store {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private lateinit var root: File

    var history by mutableStateOf<List<Item>>(emptyList())
        private set
    var favs by mutableStateOf<List<Item>>(emptyList())
        private set
    var downloads by mutableStateOf<List<DlMeta>>(emptyList())
        private set

    fun key(i: Item): String {
        val d = MessageDigest.getInstance("MD5").digest((i.source + "|" + i.url).toByteArray())
        return d.joinToString("") { "%02x".format(it) }
    }

    fun init(ctx: Context) {
        root = ctx.filesDir
        history = readList("history.json")
        favs = readList("favs.json")
        reloadDownloads()
    }

    private fun readList(name: String): List<Item> = runCatching {
        json.decodeFromString(ListSerializer(Item.serializer()), File(root, name).readText())
    }.getOrDefault(emptyList())

    private fun writeList(name: String, l: List<Item>) = runCatching {
        File(root, name).writeText(json.encodeToString(ListSerializer(Item.serializer()), l))
    }

    fun dlDir(i: Item) = File(root, "dl/" + key(i)).apply { mkdirs() }

    private fun reloadDownloads() {
        val base = File(root, "dl")
        downloads = base.listFiles().orEmpty().mapNotNull { d ->
            runCatching { json.decodeFromString(DlMeta.serializer(), File(d, "meta.json").readText()) }.getOrNull()
        }.sortedBy { it.item.title.lowercase() }
    }

    fun isFav(i: Item) = favs.any { key(it) == key(i) }

    fun toggleFav(i: Item) {
        val k = key(i)
        favs = if (favs.any { key(it) == k }) favs.filterNot { key(it) == k } else listOf(i.copy(ts = System.currentTimeMillis())) + favs
        writeList("favs.json", favs)
    }

    fun historyOf(i: Item) = history.firstOrNull { key(it) == key(i) }

    fun touch(i: Item, chapterId: Long, chapterTitle: String) {
        val k = key(i)
        val n = i.copy(ts = System.currentTimeMillis(), chapterId = chapterId, chapterTitle = chapterTitle)
        history = listOf(n) + history.filterNot { key(it) == k }.take(299)
        writeList("history.json", history)
    }

    fun removeHistory(i: Item) {
        history = history.filterNot { key(it) == key(i) }
        writeList("history.json", history)
    }

    fun metaOf(i: Item) = downloads.firstOrNull { key(it.item) == key(i) }

    fun isDownloaded(i: Item, chapterId: Long) = metaOf(i)?.chapters?.any { it.id == chapterId } == true

    @Synchronized
    fun addChapter(i: Item, c: DlChapter) {
        val old = metaOf(i)
        val chapters = (old?.chapters.orEmpty().filterNot { it.id == c.id } + c).sortedBy { it.id }
        val meta = DlMeta(i.copy(chapterId = 0, chapterTitle = ""), chapters)
        File(dlDir(i), "meta.json").writeText(json.encodeToString(DlMeta.serializer(), meta))
        reloadDownloads()
    }

    @Synchronized
    fun deleteDownload(i: Item) {
        dlDir(i).deleteRecursively()
        reloadDownloads()
    }

    @Synchronized
    fun deleteChapter(i: Item, chapterId: Long) {
        File(dlDir(i), chapterId.toString()).deleteRecursively()
        val m = metaOf(i) ?: return
        val rest = m.chapters.filterNot { it.id == chapterId }
        if (rest.isEmpty()) deleteDownload(i)
        else {
            File(dlDir(i), "meta.json").writeText(json.encodeToString(DlMeta.serializer(), m.copy(chapters = rest)))
            reloadDownloads()
        }
        Downloader.status.remove(chapterId)
    }

    /** Model yang bisa dimuat Coil: file lokal bila ada, selain itu URL. */
    fun coverModel(i: Item): Any? {
        val f = File(File(root, "dl/" + key(i)), "cover")
        return if (f.exists() && f.length() > 0) f else i.cover
    }
}

object Downloader {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val gate = Semaphore(2)

    /** chapterId -> "menunggu" | "3/20" | "selesai" | "gagal: ..." */
    val status = mutableStateMapOf<Long, String>()

    fun enqueue(item: Item, ch: MangaChapter) {
        val cur = status[ch.id]
        if (cur != null && !cur.startsWith("gagal")) return
        if (Store.isDownloaded(item, ch.id)) return
        status[ch.id] = "menunggu"
        scope.launch {
            gate.withPermit {
                val r = attempt {
                    val parser = Plugins.parser(item.source) ?: error("Plugin sumber tidak ditemukan")
                    val client = Plugins.client(parser)
                    val pages = parser.getPages(ch)
                    val dir = File(Store.dlDir(item), ch.id.toString()).apply { mkdirs() }
                    pages.forEachIndexed { i, p ->
                        status[ch.id] = "${i}/${pages.size}"
                        val f = File(dir, "%04d".format(i))
                        if (!f.exists() || f.length() == 0L) {
                            val url = parser.getPageUrl(p)
                            val tmp = File(dir, "%04d.tmp".format(i))
                            client.newCall(Request.Builder().url(url).build()).execute().use { r ->
                                if (!r.isSuccessful) error("HTTP ${r.code}")
                                r.body!!.byteStream().use { inp -> tmp.outputStream().use { inp.copyTo(it) } }
                            }
                            tmp.renameTo(f)
                        }
                    }
                    saveCover(item, client)
                    Store.addChapter(item, DlChapter(ch.id, ch.title?.takeIf { it.isNotBlank() } ?: "Chapter ${ch.number}", pages.size))
                }
                status[ch.id] = r.fold({ "selesai" }, { "gagal: ${it.readable()}" })
            }
        }
    }

    private fun saveCover(item: Item, client: okhttp3.OkHttpClient) {
        val f = File(Store.dlDir(item), "cover")
        if (f.exists() && f.length() > 0) return
        val url = item.cover ?: return
        runCatching {
            client.newCall(Request.Builder().url(url).build()).execute().use { r ->
                if (r.isSuccessful) r.body!!.byteStream().use { i -> f.outputStream().use { i.copyTo(it) } }
            }
        }
    }
}
