package id.rooki.reader

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.rememberCoroutineScope
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import tsuki.model.Manga
import tsuki.model.MangaListFilter
import tsuki.model.SortOrder

// ---------------------------------------------------------------- komponen umum

fun Manga.toItem() = Item(source.name, url, title, coverUrl, publicUrl)

@Composable
fun TopBar(title: String, onBack: (() -> Unit)? = null, actions: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Kembali") }
        else Spacer(Modifier.width(12.dp))
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        actions()
    }
}

@Composable
fun Cover(item: Item, modifier: Modifier = Modifier) {
    Box(modifier.clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
        AsyncImage(
            model = Store.coverModel(item), imageLoader = Plugins.loader(item.source),
            contentDescription = item.title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize(),
        )
    }
}

@Composable
fun MangaCard(item: Item, width: Int? = null, subtitle: String? = null, onClick: () -> Unit) {
    val m = if (width != null) Modifier.width(width.dp) else Modifier
    Column(m.clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick)) {
        Cover(item, Modifier.fillMaxWidth().aspectRatio(2f / 3f))
        Text(item.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 13.sp, fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(top = 6.dp, start = 2.dp, end = 2.dp))
        if (subtitle != null) Text(subtitle, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp,
            color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 2.dp))
    }
}

@Composable
fun SectionTitle(t: String) = Text(t, fontSize = 18.sp, fontWeight = FontWeight.Bold,
    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 10.dp))

@Composable
fun Empty(icon: ImageVector, text: String) {
    Column(Modifier.fillMaxSize().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(icon, null, Modifier.size(56.dp), tint = MaterialTheme.colorScheme.outline)
        Spacer(Modifier.height(12.dp))
        Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

fun openDetail(nav: Nav, i: Item, offline: Boolean = false) = nav.push(Screen.Detail(i, offline))

// ---------------------------------------------------------------- beranda

@Composable
fun HomeScreen(nav: Nav, goTab: (Int) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Box(
                Modifier.fillMaxWidth().padding(16.dp).clip(RoundedCornerShape(28.dp)).background(
                    Brush.linearGradient(listOf(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.surfaceVariant)),
                ).padding(22.dp),
            ) {
                Column {
                    Text("Rooki", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("Baca manga dari plugin favoritmu", color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = .8f))
                    Spacer(Modifier.height(18.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Shortcut(Icons.Default.Explore, "Jelajah") { goTab(1) }
                        Shortcut(Icons.Default.Favorite, "Favorit") { goTab(3) }
                        Shortcut(Icons.Default.Download, "Unduhan") { goTab(4) }
                        Shortcut(Icons.Default.Extension, "Plugin") { nav.push(Screen.Plugins) }
                    }
                }
            }
        }
        if (Plugins.sources.isEmpty()) item {
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp), shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(18.dp)) {
                    Text("Belum ada plugin", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("Rooki tidak membawa sumber manga sendiri. Pasang berkas plugin .lip dulu supaya sumber muncul.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 8.dp))
                    Button(onClick = { nav.push(Screen.Plugins) }) { Text("Pasang plugin") }
                }
            }
        }
        if (Store.history.isNotEmpty()) {
            item { SectionTitle("Lanjut baca") }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(Store.history.take(12), key = { Store.key(it) }) { i ->
                        MangaCard(i, 120, i.chapterTitle.ifBlank { null }) { openDetail(nav, i) }
                    }
                }
            }
        }
        if (Store.favs.isNotEmpty()) {
            item { SectionTitle("Favorit") }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(Store.favs.take(12), key = { Store.key(it) }) { i -> MangaCard(i, 120) { openDetail(nav, i) } }
                }
            }
        }
        if (Plugins.sources.isNotEmpty()) {
            item { SectionTitle("Sumber") }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(Plugins.sources.filter { !it.broken }.take(20), key = { it.name }) { s ->
                        Box(Modifier.clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { nav.push(Screen.Source(s)) }.padding(horizontal = 16.dp, vertical = 12.dp)) {
                            Text(s.title, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Shortcut(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(Modifier.clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(52.dp).clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.primary), contentAlignment = Alignment.Center) {
            Icon(icon, label, tint = MaterialTheme.colorScheme.onPrimary)
        }
        Text(label, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp), color = MaterialTheme.colorScheme.onPrimaryContainer)
    }
}

// ---------------------------------------------------------------- jelajah

@Composable
fun ExploreScreen(nav: Nav) {
    var q by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        TopBar("Jelajah", actions = { IconButton(onClick = { nav.push(Screen.Plugins) }) { Icon(Icons.Default.Extension, "Plugin") } })
        OutlinedTextField(q, { q = it }, singleLine = true, placeholder = { Text("Cari sumber") },
            leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp))
        val list = Plugins.sources.filter { it.title.contains(q, true) || it.locale.contains(q, true) }
        if (list.isEmpty()) Empty(Icons.Default.Extension, if (Plugins.sources.isEmpty()) "Belum ada plugin terpasang" else "Sumber tidak ditemukan")
        else LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list, key = { it.name }) { s ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface)
                        .clickable(enabled = !s.broken) { nav.push(Screen.Source(s)) }.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
                        Text(s.title.take(1).uppercase(), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                    Column(Modifier.padding(start = 12.dp).weight(1f)) {
                        Text(s.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(buildString { append(s.locale.ifBlank { "multi" }.uppercase()); if (s.broken) append(" · rusak") },
                            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- daftar manga satu sumber

@Composable
fun SourceScreen(src: SourceInfo, nav: Nav) {
    val parser = remember(src.name) { Plugins.parser(src.name) }
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf<List<Manga>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var end by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    var applied by remember { mutableStateOf("") }
    val orders = remember(parser) { runCatching { parser?.availableSortOrders?.toList().orEmpty() }.getOrDefault(emptyList()) }
    var order by remember { mutableStateOf<SortOrder?>(orders.firstOrNull()) }
    var menu by remember { mutableStateOf(false) }
    var gen by remember { mutableStateOf(0) }

    fun loadMore() {
        val p = parser ?: return
        val o = order ?: return
        if (loading || end) return
        loading = true
        val myGen = gen
        scope.launch {
            val r = attempt {
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    p.getList(items.size, o, MangaListFilter(query = applied.ifBlank { null }))
                }
            }
            if (myGen == gen) {
                r.onSuccess { l ->
                    val known = items.map { it.url }.toHashSet()
                    val fresh = l.filter { known.add(it.url) }
                    if (fresh.isEmpty()) end = true else items = items + fresh
                    error = null
                }.onFailure { error = it.readable(); end = true }
            }
            loading = false
        }
    }

    fun reset() { gen++; items = emptyList(); end = false; error = null; loading = false }

    Column(Modifier.fillMaxSize()) {
        TopBar(src.title, onBack = { nav.pop() }, actions = {
            if (orders.size > 1) Box {
                TextButton(onClick = { menu = true }) { Text(order?.name?.lowercase()?.replace('_', ' ') ?: "urut") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    orders.forEach { o -> DropdownMenuItem(text = { Text(o.name.lowercase().replace('_', ' ')) },
                        onClick = { menu = false; order = o; reset() }) }
                }
            }
        })
        OutlinedTextField(query, { query = it }, singleLine = true, placeholder = { Text("Cari di ${src.title}") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { query = ""; applied = ""; reset() }) { Icon(Icons.Default.Close, "Hapus") } },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { applied = query; reset() }),
            shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp))
        if (parser == null) Empty(Icons.Default.Extension, "Parser gagal dimuat dari plugin")
        else LazyVerticalGrid(
            GridCells.Adaptive(112.dp), contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            gridItems(items, key = { it.url }) { m -> MangaCard(m.toItem()) { openDetail(nav, m.toItem()) } }
            item(span = { GridItemSpan(maxLineSpan) }) {
                Box(Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.Center) {
                    when {
                        loading -> CircularProgressIndicator()
                        error != null -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(error!!, color = MaterialTheme.colorScheme.error)
                            TextButton(onClick = { end = false; error = null; loadMore() }) { Text("Coba lagi") }
                        }
                        end && items.isEmpty() -> Text("Tidak ada hasil", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        else -> LaunchedEffect(items.size, gen, order) { loadMore() }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- riwayat, favorit, unduhan

@Composable
fun HistoryScreen(nav: Nav) {
    Column(Modifier.fillMaxSize()) {
        TopBar("Riwayat")
        if (Store.history.isEmpty()) Empty(Icons.Default.History, "Belum ada riwayat bacaan")
        else LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(Store.history, key = { Store.key(it) }) { i ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface)
                    .clickable { openDetail(nav, i) }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Cover(i, Modifier.width(56.dp).aspectRatio(2f / 3f))
                    Column(Modifier.padding(start = 12.dp).weight(1f)) {
                        Text(i.title, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(i.chapterTitle.ifBlank { "—" }, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, maxLines = 1)
                        Text(Plugins.source(i.source)?.title ?: i.source, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { Store.removeHistory(i) }) { Icon(Icons.Default.Close, "Hapus") }
                }
            }
        }
    }
}

@Composable
fun FavsScreen(nav: Nav) {
    Column(Modifier.fillMaxSize()) {
        TopBar("Favorit")
        if (Store.favs.isEmpty()) Empty(Icons.Default.Favorite, "Belum ada favorit")
        else LazyVerticalGrid(GridCells.Adaptive(112.dp), contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            gridItems(Store.favs, key = { Store.key(it) }) { i -> MangaCard(i) { openDetail(nav, i) } }
        }
    }
}

@Composable
fun DownloadsScreen(nav: Nav) {
    Column(Modifier.fillMaxSize()) {
        TopBar("Unduhan")
        if (Store.downloads.isEmpty()) Empty(Icons.Default.Download, "Belum ada chapter yang diunduh")
        else LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(Store.downloads, key = { Store.key(it.item) }) { m ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface)
                    .clickable { openDetail(nav, m.item, offline = true) }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Cover(m.item, Modifier.width(56.dp).aspectRatio(2f / 3f))
                    Column(Modifier.padding(start = 12.dp).weight(1f)) {
                        Text(m.item.title, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text("${m.chapters.size} chapter tersimpan", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = { Store.deleteDownload(m.item) }) { Icon(Icons.Default.Delete, "Hapus") }
                }
            }
        }
    }
}
