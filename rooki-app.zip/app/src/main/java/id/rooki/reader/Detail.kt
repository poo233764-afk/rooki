package id.rooki.reader

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import tsuki.model.Manga
import tsuki.model.MangaPage
import java.io.File

// ---------------------------------------------------------------- detail

private fun stub(item: Item, parser: tsuki.MangaParser) = Manga(
    item.url.hashCode().toLong(), item.title, emptySet(), item.url, item.publicUrl, -1f, null,
    item.cover, emptySet(), null, emptySet(), null, null, null, parser.source,
)

@Composable
fun DetailScreen(item: Item, offline: Boolean, nav: Nav) {
    val parser = remember(item.source) { Plugins.parser(item.source) }
    var manga by remember { mutableStateOf<Manga?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(!offline) }
    var retry by remember { mutableStateOf(0) }

    LaunchedEffect(item, retry) {
        if (offline) return@LaunchedEffect
        loading = true; error = null
        if (parser == null) { error = "Plugin untuk sumber ini belum terpasang"; loading = false; return@LaunchedEffect }
        attempt { withContext(Dispatchers.IO) { parser.getDetails(stub(item, parser)) } }
            .onSuccess { manga = it }.onFailure { error = it.readable() }
        loading = false
    }

    val meta = Store.metaOf(item)
    val chaps: List<Chap> = when {
        manga?.chapters != null && !offline ->
            manga!!.chapters!!.map { Chap(it.id, it.title?.takeIf { t -> t.isNotBlank() } ?: "Chapter ${it.number}", it) }
        else -> meta?.chapters.orEmpty().map { Chap(it.id, it.title, null) }
    }
    val shown = manga?.takeIf { !offline }
    val last = Store.historyOf(item)
    val resumeIdx = chaps.indexOfFirst { it.id == last?.chapterId }.takeIf { it >= 0 }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            TopBar(item.title, onBack = { nav.pop() }, actions = {
                IconButton(onClick = { Store.toggleFav(item) }) {
                    Icon(if (Store.isFav(item)) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favorit",
                        tint = if (Store.isFav(item)) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurface)
                }
            })
            Row(Modifier.padding(16.dp)) {
                Cover(item, Modifier.width(120.dp).aspectRatio(2f / 3f))
                Column(Modifier.padding(start = 16.dp)) {
                    Text(item.title, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(Plugins.source(item.source)?.title ?: item.source, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp,
                        modifier = Modifier.padding(top = 4.dp))
                    shown?.authors?.takeIf { it.isNotEmpty() }?.let {
                        Text(it.joinToString(), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
                    }
                    shown?.state?.let {
                        Text(it.name.lowercase().replaceFirstChar { c -> c.uppercase() }, fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 2.dp))
                    }
                    if (loading) CircularProgressIndicator(Modifier.padding(top = 12.dp))
                }
            }
            if (chaps.isNotEmpty()) Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = {
                    val i = resumeIdx ?: 0
                    nav.push(Screen.Read(item, chaps, i, offline))
                }) {
                    Icon(Icons.Default.PlayArrow, null)
                    Text(if (resumeIdx != null) " Lanjutkan" else " Mulai baca")
                }
                if (!offline) FilledTonalButton(onClick = { chaps.forEach { c -> c.online?.let { Downloader.enqueue(item, it) } } }) {
                    Icon(Icons.Default.Download, null); Text(" Unduh semua")
                }
            }
            shown?.description?.takeIf { it.isNotBlank() }?.let {
                Text(it, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 6, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(16.dp))
            }
            if (error != null) Column(Modifier.padding(16.dp)) {
                Text(error!!, color = MaterialTheme.colorScheme.error)
                TextButton(onClick = { retry++ }) { Text("Coba lagi") }
            }
            if (chaps.isNotEmpty()) SectionTitle("${chaps.size} chapter")
        }
        itemsIndexed(chaps.asReversed(), key = { _, c -> c.id }) { revIdx, c ->
            val idx = chaps.size - 1 - revIdx
            val downloaded = Store.isDownloaded(item, c.id)
            val st = Downloader.status[c.id]
            Row(Modifier.fillMaxWidth().clickable { nav.push(Screen.Read(item, chaps, idx, offline)) }
                .padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(c.title, maxLines = 2, overflow = TextOverflow.Ellipsis,
                        color = if (c.id == last?.chapterId) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                    if (st != null && !downloaded) Text(st, fontSize = 11.sp,
                        color = if (st.startsWith("gagal")) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2)
                }
                when {
                    downloaded -> IconButton(onClick = { Store.deleteChapter(item, c.id) }) {
                        Icon(if (offline) Icons.Default.Delete else Icons.Default.CheckCircle, "Hapus unduhan",
                            tint = MaterialTheme.colorScheme.primary)
                    }
                    c.online != null -> IconButton(onClick = { Downloader.enqueue(item, c.online) }) { Icon(Icons.Default.Download, "Unduh") }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- pembaca

private sealed class Pg {
    class Remote(val page: MangaPage) : Pg()
    class Local(val file: File) : Pg()
}

@Composable
fun ReaderScreen(r: Screen.Read, nav: Nav) {
    val ch = r.chapters[r.index]
    val parser = remember(r.item.source) { Plugins.parser(r.item.source) }
    var pages by remember { mutableStateOf<List<Pg>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var retry by remember { mutableStateOf(0) }

    LaunchedEffect(ch.id, retry) {
        pages = null; error = null
        Store.touch(r.item, ch.id, ch.title)
        val files = File(Store.dlDir(r.item), ch.id.toString()).listFiles()
            ?.filter { it.isFile && !it.name.endsWith(".tmp") }?.sortedBy { it.name }.orEmpty()
        if (files.isNotEmpty() && Store.isDownloaded(r.item, ch.id)) {
            pages = files.map { Pg.Local(it) }
        } else if (parser != null && ch.online != null) {
            attempt { withContext(Dispatchers.IO) { parser.getPages(ch.online) } }
                .onSuccess { l -> pages = l.map { Pg.Remote(it) }; if (l.isEmpty()) error = "Chapter ini kosong" }
                .onFailure { error = it.readable() }
        } else error = "Chapter belum diunduh dan plugin tidak tersedia"
    }

    val list = pages
    Column(Modifier.fillMaxSize()) {
        TopBar(ch.title, onBack = { nav.pop() })
        when {
            error != null -> Column(Modifier.padding(24.dp)) {
                Text(error!!, color = MaterialTheme.colorScheme.error)
                TextButton(onClick = { retry++ }) { Text("Coba lagi") }
            }
            list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            else -> LazyColumn(Modifier.fillMaxSize()) {
                itemsIndexed(list) { _, pg -> PageImage(pg, r.item.source, parser) }
                item {
                    Row(Modifier.fillMaxWidth().padding(20.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        TextButton(enabled = r.index > 0, onClick = { nav.replace(r.copy(index = r.index - 1)) }) { Text("‹ Sebelumnya") }
                        TextButton(enabled = r.index < r.chapters.lastIndex, onClick = { nav.replace(r.copy(index = r.index + 1)) }) { Text("Berikutnya ›") }
                    }
                }
            }
        }
    }
}


@Composable
private fun PageImage(pg: Pg, source: String, parser: tsuki.MangaParser?) {
    var loaded by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf(false) }
    val model: Any? = when (pg) {
        is Pg.Local -> pg.file
        is Pg.Remote -> produceState<String?>(null, pg) {
            value = attempt { withContext(Dispatchers.IO) { parser!!.getPageUrl(pg.page) } }.getOrElse { failed = true; null }
        }.value
    }
    Box(Modifier.fillMaxWidth().heightIn(min = if (loaded) 0.dp else 360.dp), contentAlignment = Alignment.Center) {
        if (model != null) AsyncImage(
            model = model, imageLoader = Plugins.loader(source), contentDescription = null,
            contentScale = ContentScale.FillWidth, modifier = Modifier.fillMaxWidth(),
            onSuccess = { loaded = true }, onError = { failed = true },
        )
        if (!loaded && !failed) CircularProgressIndicator()
        if (failed && !loaded) Text("Gambar gagal dimuat", color = MaterialTheme.colorScheme.error)
    }
}

// ---------------------------------------------------------------- plugin

@Composable
fun PluginsScreen(nav: Nav) {
    val ctx = LocalContext.current
    var msg by remember { mutableStateOf<String?>(null) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) Plugins.install(ctx.contentResolver, uri)
            .onSuccess { msg = "Plugin dipasang" }.onFailure { msg = "Gagal: ${it.readable()}" }
    }
    Column(Modifier.fillMaxSize()) {
        TopBar("Plugin", onBack = { nav.pop() })
        Column(Modifier.padding(16.dp)) {
            Button(onClick = { pick.launch(arrayOf("*/*")) }) { Icon(Icons.Default.Extension, null); Text(" Pasang plugin (.lip)") }
            msg?.let { Text(it, modifier = Modifier.padding(top = 8.dp), color = MaterialTheme.colorScheme.primary) }
        }
        if (Plugins.files.isEmpty()) Empty(Icons.Default.Extension, "Belum ada plugin. Pilih berkas .lip untuk memasang.")
        else LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            itemsIndexed(Plugins.files) { _, f ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(f.file.name, fontWeight = FontWeight.SemiBold)
                        if (f.error != null) Text(f.error, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                        else Text("${f.sources} sumber", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { Plugins.remove(f) }) { Icon(Icons.Default.Delete, "Hapus") }
                }
            }
        }
    }
}
