package id.rooki.reader

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

private val DarkScheme = darkColorScheme(
    primary = Color(0xFF9D86FF), onPrimary = Color(0xFF1B0F4A),
    primaryContainer = Color(0xFF3A2D8C), onPrimaryContainer = Color(0xFFE6DEFF),
    secondary = Color(0xFFC6B8FF), tertiary = Color(0xFFFF8FB8),
    background = Color(0xFF0E0B1F), onBackground = Color(0xFFEDE9FF),
    surface = Color(0xFF16122B), onSurface = Color(0xFFEDE9FF),
    surfaceVariant = Color(0xFF241E45), onSurfaceVariant = Color(0xFFB9B2DD),
    outline = Color(0xFF6E64A8), error = Color(0xFFFF7A8A),
)
private val LightScheme = lightColorScheme(
    primary = Color(0xFF5B3FD9), onPrimary = Color.White,
    primaryContainer = Color(0xFFDDD5FF), onPrimaryContainer = Color(0xFF1E0F6B),
    secondary = Color(0xFF6F5FC2), tertiary = Color(0xFFC2306A),
    background = Color(0xFFF7F5FF), onBackground = Color(0xFF1A1633),
    surface = Color.White, onSurface = Color(0xFF1A1633),
    surfaceVariant = Color(0xFFEAE5FF), onSurfaceVariant = Color(0xFF5A5380),
    outline = Color(0xFF8A82B8), error = Color(0xFFBA1A3A),
)

@Composable
fun RookiTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) DarkScheme else LightScheme, content = content)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { RookiTheme { RookiRoot() } }
    }
}

sealed class Screen {
    object Plugins : Screen()
    data class Source(val src: SourceInfo) : Screen()
    data class Detail(val item: Item, val offline: Boolean = false) : Screen()
    data class Read(val item: Item, val chapters: List<Chap>, val index: Int, val offline: Boolean) : Screen()
}

class Chap(val id: Long, val title: String, val online: tsuki.model.MangaChapter?)

class Nav(val stack: androidx.compose.runtime.snapshots.SnapshotStateList<Screen>) {
    fun push(s: Screen) { stack.add(s) }
    fun pop() { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex) }
    fun replace(s: Screen) { if (stack.isNotEmpty()) stack[stack.lastIndex] = s else stack.add(s) }
}

@Composable
fun RookiRoot() {
    val stack = remember { mutableStateListOf<Screen>() }
    val nav = remember { Nav(stack) }
    var tab by rememberSaveable { mutableIntStateOf(0) }

    BackHandler(enabled = stack.isNotEmpty() || tab != 0) {
        if (stack.isNotEmpty()) nav.pop() else tab = 0
    }

    val tabs = listOf("Beranda" to Icons.Default.Home, "Jelajah" to Icons.Default.Explore,
        "Riwayat" to Icons.Default.History, "Favorit" to Icons.Default.Favorite, "Unduhan" to Icons.Default.Download)

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (stack.isEmpty()) NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                tabs.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i },
                        icon = { Icon(icon, label) }, label = { Text(label) })
                }
            }
        },
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(bottom = pad.calculateBottomPadding()).statusBarsPadding()) {
            when (val s = stack.lastOrNull()) {
                null -> when (tab) {
                    0 -> HomeScreen(nav) { tab = it }
                    1 -> ExploreScreen(nav)
                    2 -> HistoryScreen(nav)
                    3 -> FavsScreen(nav)
                    else -> DownloadsScreen(nav)
                }
                is Screen.Plugins -> PluginsScreen(nav)
                is Screen.Source -> SourceScreen(s.src, nav)
                is Screen.Detail -> androidx.compose.runtime.key(s) { DetailScreen(s.item, s.offline, nav) }
                is Screen.Read -> androidx.compose.runtime.key(s) { ReaderScreen(s, nav) }
            }
        }
    }
}
