#!/usr/bin/env bash
# Ambil kerangka parser (Kotatsu parsers), ganti nama paket jadi "tsuki", lalu tambal agar cocok dengan plugin .lip
set -euo pipefail
rm -rf up
git clone --depth 1 https://github.com/KotatsuApp/kotatsu-parsers.git up
SRC=up/src/main/kotlin/org/koitharu/kotatsu/parsers
test -d "$SRC" || { echo "Folder sumber tidak ditemukan"; exit 1; }
DST=app/src/main/java/tsuki
rm -rf "$DST"; mkdir -p "$DST"
cp -r "$SRC"/. "$DST"/
cd "$DST"
rm -rf site
grep -rl 'org.koitharu.kotatsu.parsers' . | xargs sed -i 's/org\.koitharu\.kotatsu\.parsers/tsuki/g'
# MangaParserSource (enum buatan KSP) ada di dalam plugin; aplikasi hanya mengenal antarmuka MangaSource
grep -rl 'MangaParserSource' . | xargs sed -i 's/MangaParserSource/MangaSource/g'
cat > model/MangaSource.kt <<'K'
package tsuki.model

public interface MangaSource {
	public val name: String
	public val locale: String
	public val contentType: ContentType
}
K
# newParserInstance diimplementasikan oleh aplikasi (lihat RookiContext)
sed -i 's/public fun newParserInstance(source: MangaSource): MangaParser = source.newParser(this)/public abstract fun newParserInstance(source: MangaSource): MangaParser/' MangaLoaderContext.kt
# LinkResolver tidak bisa menelusuri semua sumber; lewati bagian itu
perl -0pi -e 's/for \(s in MangaSource\.entries\) \{.*?\n\t\t\}\n\t\tnull/null/s' util/LinkResolver.kt
echo "--- periksa tambalan"
grep -n 'newParserInstance' MangaLoaderContext.kt
grep -n 'MangaSource.entries' -r . || echo "ok: tidak ada MangaSource.entries"
echo "jumlah berkas kt: $(find . -name '*.kt' | wc -l)"
